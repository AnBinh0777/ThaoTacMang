﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace thao_tac_mang
{
   public  class CMangPhanTu
    {
        int[] DanhSachPhanTu;
        int soPT;
        public CMangPhanTu (int sophantu)
        {
            DanhSachPhanTu = new int[1000];
            soPT = sophantu;
        }
        public void TaoMangNgauNhien(int sophantu)
        {
            Random r = new Random();
            soPT = sophantu;
            for (int i=0; i < sophantu;i++)
            {
                DanhSachPhanTu[i] = r.Next(100);
            }
        }
        public void DaoMang(int sophantu)
        {
            for(int i=0;i<=soPT/2;i++)
            {
                int r = DanhSachPhanTu[i];
                DanhSachPhanTu[i] = DanhSachPhanTu[(soPT - 1) - i];
                DanhSachPhanTu[(soPT - 1) - i] = r;
            }
        }
        public void TaoMangTangDan(int sophantu)
        {
            soPT = sophantu;
            Random r = new Random();
            DanhSachPhanTu[0] = r.Next(100);
            for (int i = 1; i < sophantu; i++)
            {
                DanhSachPhanTu[i] = DanhSachPhanTu[i - 1] + r.Next(100);
            }
        }
        public int TongPhanTu(int ViTriDau, int ViTriCuoi)
        {
        int tong = 0;
        for (int i=ViTriDau-1; i< ViTriCuoi;i++)
            { 
            tong=tong+DanhSachPhanTu[i];
            }
        return tong;
        }
       public void XoaPhanTu(int vitri,int giatricanxoa)
        {
            for (int i = vitri - 1; i < soPT; i++)
            {
                if (DanhSachPhanTu [i]==giatricanxoa )
                {
                    DanhSachPhanTu[i] = DanhSachPhanTu[i + 1];
                }
             //   return soPT--;
            }
            
        }
        public void ThemPhanTu(int vitri, int phantuthemvao)
        {
            for (int i = soPT; i >= vitri; i--)
            {
                DanhSachPhanTu[i] = DanhSachPhanTu[i - 1];
            }
            DanhSachPhanTu[vitri - 1] = phantuthemvao;
            soPT++;
        }




        public string XuatMang()
        {
            string r = "";
            for (int i=0;i<soPT ;i++)
            {
                r += DanhSachPhanTu[i].ToString()+" ; ";
            }
            return r;
        }

    }
}
