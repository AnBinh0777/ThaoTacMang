﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace thao_tac_mang
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        int sophantu = 0;
        CMangPhanTu MangPhanTu;

        private void btnTaoMangNgauNhien_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnTaoMangNgauNhien_Click_1(object sender, RoutedEventArgs e)
        {
            sophantu = int.Parse(txtSoLuongPhanTu.Text );
            MangPhanTu = new CMangPhanTu(sophantu) ;
            MangPhanTu.TaoMangNgauNhien(sophantu);
            txtMangPhanTu.Text = MangPhanTu.XuatMang();

        }

        private void btnTaoMangTangDan_Click(object sender, RoutedEventArgs e)
        {
            sophantu = int.Parse(txtSoLuongPhanTu.Text);
            MangPhanTu.TaoMangTangDan(sophantu);
            txtMangPhanTu.Text = MangPhanTu.XuatMang();
        }

        private void btnDaoMang_Click(object sender, RoutedEventArgs e)
        {
         
            MangPhanTu.DaoMang(sophantu);
            txtMangPhanTu.Text = MangPhanTu.XuatMang();
        }

        private void txtKetQuaTinhTong_TextChanged(object sender, TextChangedEventArgs e)
        {
            

        }

        private void btnKetQuaTinhTong_Click(object sender, RoutedEventArgs e)
        {
            int tong;
            tong = MangPhanTu.TongPhanTu(int.Parse(txtViTriBatDauTinhTong.Text), int.Parse(txtViTriKetThucTinhTong.Text));
            txtKetQuaTinhTong.Text = tong.ToString();
        }

        private void btnXoaPhanTu_Click(object sender, RoutedEventArgs e)
        {
            int giatricanxoa = int.Parse(txtPhanTuCanTimXoa.Text);
            MangPhanTu.XoaPhanTu(int.Parse(txtPhanTuCanTimXoa.Text));
            txtMangPhanTu.Text = MangPhanTu.XuatMang();

        }

        private void txtPhanTuCanSuaXoa_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void btnViTriDau_Click(object sender, RoutedEventArgs e)
        {
            MangPhanTu.ThemPhanTu(1, int.Parse(txtPhanTuCanChen.Text));
            sophantu++;
            txtMangPhanTu.Text = MangPhanTu.XuatMang();
        }

        private void txtPhanTuCanChen_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void btnViTriCuoi_Click(object sender, RoutedEventArgs e)
        {
            MangPhanTu.ThemPhanTu(sophantu + 1, int.Parse(txtPhanTuCanChen.Text));
            sophantu++;
            txtMangPhanTu.Text = MangPhanTu.XuatMang();
        }

        private void btnViTriBatKi_Click(object sender, RoutedEventArgs e)
        {
            MangPhanTu.ThemPhanTu(int.Parse(txtViTriBatKi.Text), int.Parse(txtViTriBatKi.Text));
            sophantu++;
            txtMangPhanTu.Text = MangPhanTu.XuatMang();
        }

        private void txtSoLuongPhanTu_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        /* private void btnXoaPhanTu_Click(object sender, RoutedEventArgs e)
         {
             sophantu = int.Parse(txtSoLuongPhanTu.Text);
             MangPhanTu = new CMangPhanTu(sophantu);
             txtMangPhanTu.Text = MangPhanTu.XoaPhanTu.Text;
             MangPhanTu.TaoMangTangDan(sophantu);
             txtMangPhanTu.Text = MangPhanTu.XuatMang();

         }*/
    }
}
